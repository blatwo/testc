#include "include/hello.h"
void say_hello(char * name){
    printf("Hello, %s!\n", name);
}

