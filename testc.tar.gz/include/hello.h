#include<stdio.h>
void say_hello(char *name);

