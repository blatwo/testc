# testc
instance for C language study~
