#include<hello.h>
int main(){
    say_hello("Tom");
}

